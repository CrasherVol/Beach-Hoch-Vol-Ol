export default function Sun(){
  return (
    <div aria-hidden className="fixed right-5 top-3 pointer-events-none z-50 select-none">
      <div className="relative">
        <div className="absolute -inset-6 rounded-full" style={{background:'radial-gradient(circle, rgba(251,191,36,.55), rgba(251,191,36,0) 60%)', filter:'blur(10px)'}}/>
        <div className="absolute -inset-10 rounded-full" style={{background:'radial-gradient(circle, rgba(56,189,248,.35), rgba(56,189,248,0) 65%)', filter:'blur(16px)'}}/>
        <div className="text-6xl animate-[spin_8s_linear_infinite]">☀️</div>
      </div>
    </div>
  )
}
