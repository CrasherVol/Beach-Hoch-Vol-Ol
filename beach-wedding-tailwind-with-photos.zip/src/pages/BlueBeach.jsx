import Card from '../components/Card.jsx'

export default function BlueBeach(){
  return (
    <div className="py-6">
      <h2 className="text-2xl font-bold mb-3">Was ist das BlueBeach in Witten?</h2>
      <div className="grid md:grid-cols-3 gap-3 my-4">
        <img src="/assets/bb-outdoor.webp" alt="BlueBeach Außenbereich" className="w-full h-[220px] object-cover rounded-2xl shadow"/>
        <img src="/assets/bb-indoor.webp" alt="BlueBeach Indoorhalle" className="w-full h-[220px] object-cover rounded-2xl shadow"/>
        <img src="/assets/bb-courts.jpg" alt="BlueBeach Beachplätze" className="w-full h-[220px] object-cover rounded-2xl shadow"/>
      </div>
      <div className="grid md:grid-cols-3 gap-4">
        <Card title="Strandfeeling"><p>Indoor‑Strand & Außenbereich mit feinem Sand, Palmen und Lichterketten.</p></Card>
        <Card title="Beachsport"><p>Mehrere Beachcourts (Indoor & Outdoor) – 365 Tage bespielbar.</p></Card>
        <Card title="Events & Bar"><p>Bar mit Drinks & Snacks, Bereiche für private Feiern und Partys.</p></Card>
      </div>
      <div className="mt-6">
        <img src="/assets/bb-party.jpg" alt="Event im BlueBeach" className="w-full max-h-[420px] object-cover rounded-2xl shadow"/>
      </div>
    </div>
  )
}
