import Card from '../components/Card.jsx'
import { useState } from 'react'

export default function Home(){
  const imgs=[
    {alt:'Hängematte am Strand', src:'/assets/hero-hammock.jpg'},
    {alt:'Feier mit Drinks', src:'/assets/party-drinks.png'},
    {alt:'Sonnenuntergang & Palmen', src:'/assets/sunset-palm.jpg'} // placeholder
  ]
  const [open,setOpen]=useState(null)
  return (
    <section className="py-12">
      <div className="grid gap-7 md:grid-cols-[1.2fr_.8fr] items-center">
        <div>
          <img src="/logo.png" alt="Volker & Olga – Logo" className="hero-logo glow"/>
          <h1 className="text-3xl md:text-5xl font-extrabold leading-tight mt-3">Hochzeitsfeier am Strand – Volker & Olga</h1>
          <p className="text-slate-600 mt-1">Beachfeeling im <b>BlueBeach Witten</b> mit Sonne, Sand und Liebe. Fingerfood & Drinks inklusive.</p>
          <div className="flex gap-2 mt-3">
            <a href="/anmeldung" className="px-4 py-2 rounded-xl text-white bg-gradient-to-tr from-emerald-500 to-orange-400 shadow hover:scale-[1.02] transition">Jetzt anmelden</a>
            <a href="/bluebeach" className="px-4 py-2 rounded-xl bg-white shadow hover:scale-[1.02] transition">BlueBeach ansehen</a>
          </div>
        </div>
        <div className="grid gap-3">
          <Card title="Sommerfeeling"><p>Sand zwischen den Zehen, Palmen & Lichterketten – gemütlich & elegant.</p></Card>
          <Card title="Beachvolleyball"><p>Wer mag, spielt ein paar lockere Runden. Zuschauer willkommen!</p></Card>
          <Card title="Drinks & Fingerfood"><p>Unkompliziert genießen – vegetarische Optionen vorhanden.</p></Card>
        </div>
      </div>
      <div className="grid md:grid-cols-3 gap-3 my-7">
        {imgs.map((i,idx)=>(<img key={idx} alt={i.alt} src={i.src} className="w-full h-[260px] object-cover rounded-2xl shadow cursor-pointer" />))}
      </div>
    </section>
  )
}
