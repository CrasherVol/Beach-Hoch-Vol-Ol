import { NavLink, Outlet } from 'react-router-dom'
import Sun from './components/Sun.jsx'
import CursorBall from './components/CursorBall.jsx'

export default function App(){
  return (
    <div className="min-h-screen relative cursor-none bg-sand">
      <Sun/><CursorBall/>
      <header className="sticky top-0 z-40 backdrop-blur-md bg-white/60 border-b border-white/60">
        <div className="max-w-[1100px] mx-auto px-4 py-3 flex items-center justify-between">
          <a href="/" className="flex items-center gap-3 font-extrabold"><img src="/logo.png" alt="Logo" className="h-9 w-auto rounded-xl shadow"/> <span>Volker ❤ Olga</span></a>
          <nav className="flex gap-2 items-center">
            <NavLink to="/" end className={({isActive})=>`px-3 py-2 rounded-xl ${isActive?'bg-indigo-50':'hover:bg-white/70'}`}>Start</NavLink>
            <NavLink to="/bluebeach" className={({isActive})=>`px-3 py-2 rounded-xl ${isActive?'bg-indigo-50':'hover:bg-white/70'}`}>BlueBeach</NavLink>
            <a href="/anmeldung" className="px-3 py-2 rounded-xl text-white bg-gradient-to-tr from-emerald-500 to-orange-400 shadow hover:scale-[1.02] transition">Anmeldung</a>
          </nav>
        </div>
      </header>
      <main className="max-w-[1100px] mx-auto px-4">
        <Outlet/>
      </main>
      <footer className="mt-10 bg-white/60 border-t border-white/60"><div className="max-w-[1100px] mx-auto px-4 py-6">© {new Date().getFullYear()} Volker & Olga · BlueBeach Witten</div></footer>
    </div>
  )
}
