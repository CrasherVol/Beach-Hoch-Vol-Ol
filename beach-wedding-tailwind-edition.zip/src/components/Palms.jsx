export default function Palms(){
  return (
    <div aria-hidden className="palms">
      <div className="rotate-[-6deg]">🌴</div>
      <div className="rotate-[6deg]">🌴</div>
    </div>
  );
}
