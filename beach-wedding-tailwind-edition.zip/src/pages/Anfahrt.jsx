import Card from '../components/Card.jsx'
import SEO from '../components/SEO.jsx'

export default function Anfahrt(){
  return (
    <div className="page py-6">
      <SEO title="Anfahrt – BlueBeach Witten" description="Adresse, Karte und Parkhinweise für das BlueBeach in Witten."/>
      <h2 className="text-2xl font-bold mb-3">Anfahrt zum BlueBeach in Witten</h2>
      <div className="grid md:grid-cols-2 gap-4">
        <Card title="Adresse">
          <p>BlueBeach Witten<br/>Luhnsmühle 2<br/>58455 Witten</p>
          <div className="mt-2">
            <a className="px-3 py-2 rounded-xl text-white bg-gradient-to-tr from-emerald-500 to-orange-400 shadow-soft inline-block" target="_blank" href="https://www.google.com/maps/search/?api=1&query=BlueBeach+Witten" rel="noreferrer">In Google Maps öffnen</a>
          </div>
        </Card>
        <Card title="Karte">
          <div className="rounded-2xl overflow-hidden shadow-soft">
            <iframe title="BlueBeach Map" className="border-0 w-full h-[320px]" loading="lazy" referrerPolicy="no-referrer-when-downgrade" src="https://www.google.com/maps?q=BlueBeach%20Witten&output=embed"></iframe>
          </div>
        </Card>
      </div>
      <div className="grid md:grid-cols-2 gap-4 mt-4">
        <Card title="Parken & ÖPNV">
          <ul className="list-disc pl-6">
            <li>Parkplätze am Gelände vorhanden.</li>
            <li>Bitte Fahrgemeinschaften bilden.</li>
            <li>ÖPNV: Haltestelle Freizeitbad Heveney → wenige Gehminuten.</li>
          </ul>
        </Card>
      </div>
    </div>
  )
}
