# Volker ❤ Olga – Beach Wedding (Vite + React)

Features:
- Start/Hero mit Logo (+ Glow), Sonne, Palmen, Volleyball-Cursor
- Seiten: Anfahrt, BlueBeach, Dresscode, Ablauf, Anmeldung (RSVP), Hotels (mit Galerie)
- Lightbox-Galerien, SEO/OG-Meta, OG-Sharing-Bild
- Goldenes Herz+Sonne-Favicon

## Setup
npm install
npm run dev

## Build
npm run build
