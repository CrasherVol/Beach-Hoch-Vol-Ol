import Card from '../components/Card.jsx'
import SEO from '../components/SEO.jsx'

export default function BlueBeach(){
  return (
    <div className="page">
      <SEO title="BlueBeach – Was ist das?" description="Eventlocation mit Sand, Palmen und Beachvolleyball – perfekte Strandbar-Atmosphäre."/>
      <h2>Was ist das BlueBeach in Witten?</h2>
      <div className="grid3">
        <Card title="Strandfeeling"><p>Feiner Sand, Palmen und Lichterketten – eine Strandbar mitten im Ruhrgebiet.</p></Card>
        <Card title="Aktivitäten"><p>Loungen, Tanzen oder Beachvolleyball – ganz wie ihr wollt.</p></Card>
        <Card title="Kulinarik"><p>Drinks & Fingerfood – unkompliziert, lecker, entspannt.</p></Card>
      </div>
    </div>
  )
}
