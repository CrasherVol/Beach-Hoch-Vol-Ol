import { useState } from 'react'
import Card from '../components/Card.jsx'
import SEO from '../components/SEO.jsx'

export default function Anmeldung(){
  const [sent, setSent] = useState(false)
  const [f, setF] = useState({name:'', email:'', persons:1, message:'', allergies:''})
  const onChange = e => setF(v=>({...v,[e.target.name]: e.target.type==='number'? Number(e.target.value): e.target.value}))
  const onSubmit = e => {
    e.preventDefault()
    const list = JSON.parse(localStorage.getItem('rsvp-list')||'[]')
    list.push({...f, ts:new Date().toISOString()})
    localStorage.setItem('rsvp-list', JSON.stringify(list))
    setSent(true)
  }
  if(sent){
    return (
      <div className="page">
        <SEO title="Danke – Anmeldung" />
        <Card title="Danke für deine Zusage!">
          <p>Wir haben dich mit <b>{f.persons}</b> Person(en) vermerkt. Eine Bestätigung folgt (Demo).</p>
          <a href="/" className="btn">Zur Startseite</a>
        </Card>
      </div>
    )
  }
  return (
    <div className="page">
      <SEO title="Anmeldung" description="Sag uns kurz Bescheid, mit wie vielen Personen du kommst."/>
      <h2>Anmeldung</h2>
      <Card>
        <form onSubmit={onSubmit} className="form">
          <label>Name<input required name="name" value={f.name} onChange={onChange} placeholder="Vor- und Nachname"/></label>
          <label>E‑Mail<input required type="email" name="email" value={f.email} onChange={onChange} placeholder="du@example.com"/></label>
          <label>Personen<input required type="number" name="persons" min={1} max={12} value={f.persons} onChange={onChange}/></label>
          <label>Allergien (optional)<input name="allergies" value={f.allergies} onChange={onChange} placeholder="z.B. Nüsse, Gluten…"/></label>
          <label>Nachricht (optional)<textarea name="message" rows="4" value={f.message} onChange={onChange} placeholder="Wünsche, Grüße…"/></label>
          <button className="btn primary">Zusage senden</button>
          <p className="hint">Datenschutz: Angaben nur zur Organisation der Feier (Demo).</p>
        </form>
      </Card>
    </div>
  )
}
