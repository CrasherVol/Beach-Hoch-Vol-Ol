export default function Palms(){
  return (
    <div aria-hidden className="palms">
      <div className="palm palm-left">🌴</div>
      <div className="palm palm-right">🌴</div>
    </div>
  );
}
