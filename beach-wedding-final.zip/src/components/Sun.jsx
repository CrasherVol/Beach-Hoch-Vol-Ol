export default function Sun(){ return <div aria-hidden className='sun' title='Sommer-Sonne'>☀️</div>; }
