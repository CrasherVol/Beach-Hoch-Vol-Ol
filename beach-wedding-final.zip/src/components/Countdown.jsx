import { useEffect, useState } from 'react'
export const EVENT_DATE = new Date('2026-02-13T17:00:00+01:00')
export default function Countdown(){
  const [now, setNow] = useState(new Date())
  useEffect(()=>{ const t=setInterval(()=>setNow(new Date()),1000); return ()=>clearInterval(t); },[])
  const diff = Math.max(0, EVENT_DATE - now)
  const d = Math.floor(diff/86400000)
  const h = Math.floor((diff/3600000)%24)
  const m = Math.floor((diff/60000)%60)
  const s = Math.floor((diff/1000)%60)
  return (
    <div className="countdown">
      <span><b>{d}</b>T</span>
      <span><b>{h}</b>h</span>
      <span><b>{m}</b>m</span>
      <span><b>{s}</b>s</span>
    </div>
  )
}
