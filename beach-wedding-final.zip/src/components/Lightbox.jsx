export default function Lightbox({src, alt, onClose}){
  if(!src) return null
  return (
    <div className="lightbox-backdrop" onClick={onClose}>
      <img className="lightbox-img" src={src} alt={alt||'Bild'} />
    </div>
  )
}
