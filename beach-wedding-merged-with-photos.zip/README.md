# Volker ❤ Olga – Beach Wedding (Tailwind Edition)

- TailwindCSS integriert (edler, warm-sommerlicher Stil)
- Sonne (verstärkt strahlend), Palmen, Beachvolleyball-Cursor
- Seiten: Start, Anfahrt, BlueBeach (mehr Infos), Dresscode, Ablauf, Anmeldung, Hotels
- OG-Image & Favicon bitte in /public legen (Dateien: `og-image.jpg`, `favicon.ico`, `logo.png`)

## Setup
npm install
npm run dev

## Build
npm run build
npm run preview
