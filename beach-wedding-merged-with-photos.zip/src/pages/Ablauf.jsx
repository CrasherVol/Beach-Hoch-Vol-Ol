import Card from '../components/Card.jsx'
import SEO from '../components/SEO.jsx'

export default function Ablauf(){
  const dateStr = new Intl.DateTimeFormat('de-DE',{dateStyle:'full'}).format(new Date('2026-02-13T17:00:00+01:00'))
  return (
    <div className="page py-6">
      <SEO title="Ablauf" description="Zeitplan, Fingerfood & Getränke für den Abend."/>
      <h2 className="text-2xl font-bold mb-3">Ablauf – {dateStr}</h2>
      <div className="grid md:grid-cols-2 gap-4">
        <Card title="Zeitplan (Beispiel)">
          <ul className="list-disc pl-6">
            <li><b>17:00</b> Eintreffen & Welcome‑Drink</li>
            <li><b>18:00</b> Begrüßung Volker & Olga</li>
            <li><b>18:15</b> Fingerfood‑Buffet öffnet</li>
            <li><b>19:30</b> Fotos, Beachvolleyball & Chill</li>
            <li><b>21:00</b> Dessert & Anstoßen</li>
            <li><b>open end</b> Musik & Strandfeuer (wetterabhängig)</li>
          </ul>
        </Card>
        <Card title="Essen & Getränke">
          <ul className="list-disc pl-6">
            <li>Es gibt <b>nur Fingerfood</b> und <b>Getränke</b>.</li>
            <li>Vegetarische Optionen vorhanden.</li>
            <li>Bitte Allergien in der Anmeldung angeben.</li>
          </ul>
        </Card>
      </div>
    </div>
  )
}
