import Card from '../components/Card.jsx'
import SEO from '../components/SEO.jsx'

export default function Dresscode(){
  return (
    <div className="page py-6">
      <SEO title="Dresscode – Elegant & Beachy" description="Sommerlich-elegante Outfits, bequem im Sand – Beispielideen und Tipps."/>
      <h2 className="text-2xl font-bold mb-3">Dresscode: Elegant & Beachy</h2>
      <div className="grid md:grid-cols-2 gap-4">
        <Card title="Für Sie (Beispiele)">
          <ul className="list-disc pl-6">
            <li>Leichtes Sommerkleid (Leinen/Chiffon)</li>
            <li>Elegante Sandalen / Keilabsätze (flach empfohlen)</li>
            <li>Farben: Pastell, sand, türkis, koralle</li>
            <li>Optional: Sonnenhut, Tuch</li>
          </ul>
        </Card>
        <Card title="Für Ihn (Beispiele)">
          <ul className="list-disc pl-6">
            <li>Leinenhemd oder feines Polo, evtl. leichtes Sakko</li>
            <li>Chino/Leinenhose, ggf. kurze Stoffhose</li>
            <li>Saubere Sneakers/Loafer</li>
            <li>Farben: hell, natur, navy</li>
          </ul>
        </Card>
      </div>
    </div>
  )
}
