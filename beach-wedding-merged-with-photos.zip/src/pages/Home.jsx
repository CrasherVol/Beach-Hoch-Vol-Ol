import Countdown from '../components/Countdown.jsx'
import Card from '../components/Card.jsx'
import Lightbox from '../components/Lightbox.jsx'
import SEO from '../components/SEO.jsx'
import { useState } from 'react'

export default function Home(){
  const date = new Intl.DateTimeFormat('de-DE',{dateStyle:'full'}).format(new Date('2026-02-13T17:00:00+01:00'))
  const imgs = [
    {alt:'Feier edel am Beach', src:'/assets/party-drinks-2.png'},
    {alt:'Strandliege', src:'/assets/hero-hammock.jpg'},
    {alt:'Lichterketten Strandbar', src:'/assets/party-drinks.png'},
    {alt:'Beachvolleyball Netz', src:'/assets/sunset-palm.jpg'}
  ]
  const [open, setOpen] = useState(null)
  return (
    <div className="home">
      <SEO title="Volker ❤ Olga – Beach Wedding" description="Sommerliche Hochzeit im BlueBeach Witten – 13.02.2026. Fingerfood, Drinks & Beachvolleyball." />
      <section className="py-12">
        <div className="grid gap-7 md:grid-cols-[1.2fr_.8fr] items-center">
          <div>
            <img src="/logo.png" alt="Volker & Olga – Logo" className="hero-logo animate-logoGlow"/>
            <h1 className="text-3xl md:text-5xl font-extrabold leading-tight mt-3">Hochzeitsfeier am Strand – Volker & Olga</h1>
            <p className="text-slate-600 mt-1">Beachfeeling im <b>BlueBeach Witten</b> mit Sonne, Sand und Liebe. Fingerfood & Drinks inklusive.</p>
            <div className="flex gap-2 flex-wrap mt-2">
              <span className="bg-white/70 px-3 py-1 rounded-full shadow-soft">{date}</span>
              <span className="bg-white/70 px-3 py-1 rounded-full shadow-soft">BlueBeach · Witten</span>
              <span className="bg-white/70 px-3 py-1 rounded-full shadow-soft">Sommer‑Vibes</span>
            </div>
            <div className="mt-3"><Countdown/></div>
            <div className="flex gap-2 mt-3">
              <a href="/anmeldung" className="px-4 py-2 rounded-xl text-white bg-gradient-to-tr from-emerald-500 to-orange-400 shadow-soft hover:scale-[1.02] transition">Jetzt anmelden</a>
              <a href="/anfahrt" className="px-4 py-2 rounded-xl bg-white shadow-soft hover:scale-[1.02] transition">Anfahrt</a>
            </div>
          </div>
          <div className="grid gap-3">
            <Card title="Sommerfeeling">
              <p>Sand zwischen den Zehen, Palmen & Lichterketten – gemütlich & elegant.</p>
            </Card>
            <Card title="Beachvolleyball">
              <p>Wer mag, spielt ein paar lockere Runden. Zuschauer willkommen!</p>
            </Card>
            <Card title="Drinks & Fingerfood">
              <p>Unkompliziert genießen – vegetarische Optionen vorhanden.</p>
            </Card>
          </div>
        </div>
      </section>

      <section className="grid md:grid-cols-3 gap-3 my-7">
        {imgs.map((i,idx)=>(
          <img key={idx} alt={i.alt} src={i.src} onClick={()=>setOpen(i.src)} className="w-full h-[260px] object-cover rounded-2xl shadow-soft cursor-pointer" />
        ))}
        <Lightbox src={open} alt="Galerie" onClose={()=>setOpen(null)} />
      </section>
    </div>
  )
}
