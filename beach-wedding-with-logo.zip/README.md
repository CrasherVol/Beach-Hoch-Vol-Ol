# Volker ❤ Olga – Beach Wedding (Vite + React)

Sommerliche Hochzeitsseite mit:
- Start/Hero (Countdown, Sommerhintergrund, Sonne, Palmen, Volleyball-Cursor)
- Unterseiten: Anfahrt, BlueBeach, Dresscode, Ablauf, Anmeldung (RSVP)
- Galerie mit Lightbox
- SEO per `react-helmet-async`
- Admin-Seite mit CSV-Export der RSVPs

## Setup
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
npm run preview
```
