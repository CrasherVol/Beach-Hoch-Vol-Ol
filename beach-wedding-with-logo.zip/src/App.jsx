import { NavLink, Outlet } from 'react-router-dom'
import Sun from './components/Sun.jsx'
import CursorBall from './components/CursorBall.jsx'
import Palms from './components/Palms.jsx'

export default function App(){
  return (
    <div className="app-shell">
      <Sun />
      <Palms />
      <CursorBall />
      <header className="site-header">
        <div className="container nav-inner">
          <a href="/" className="brand brand-logo"><img src="/logo.png" alt="Volker & Olga – Logo"/><span className="brand-text">Volker ❤ Olga</span></a>
          <nav className="nav">
            <NavLink to="/" end>Start</NavLink>
            <NavLink to="/anfahrt">Anfahrt</NavLink>
            <NavLink to="/bluebeach">BlueBeach</NavLink>
            <NavLink to="/dresscode">Dresscode</NavLink>
            <NavLink to="/ablauf">Ablauf</NavLink>
            <NavLink to="/hotels">Hotelinfos</NavLink>
            <NavLink to="/anmeldung" className="cta">Anmeldung</NavLink>
          </nav>
        </div>
      </header>
      <main className="container">
        <Outlet />
      </main>
      <footer className="site-footer">
        <div className="container">© {new Date().getFullYear()} Volker & Olga · BlueBeach Witten · <a href="/admin">Admin</a></div>
      </footer>
    </div>
  )
}
