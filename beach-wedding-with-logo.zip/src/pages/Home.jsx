import Countdown from '../components/Countdown.jsx'
import Card from '../components/Card.jsx'
import Lightbox from '../components/Lightbox.jsx'
import SEO from '../components/SEO.jsx'
import { useState } from 'react'

export default function Home(){
  const date = new Intl.DateTimeFormat('de-DE',{dateStyle:'full'}).format(new Date('2026-02-13T17:00:00+01:00'))
  const imgs = [
    {alt:'Strandliege', src:'https://images.unsplash.com/photo-1493558103817-58b2924bce98?q=80&w=1600&auto=format&fit=crop'},
    {alt:'Lichterketten Strandbar', src:'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?q=80&w=1600&auto=format&fit=crop'},
    {alt:'Beachvolleyball Netz', src:'https://images.unsplash.com/photo-1518131678677-a09d92e87f2f?q=80&w=1600&auto=format&fit=crop'}
  ]
  const [open, setOpen] = useState(null)
  return (
    <div className="home">
      <SEO title="Volker ❤ Olga – Beach Wedding" description="Sommerliche Hochzeit im BlueBeach Witten – 13.02.2026. Fingerfood, Drinks & Beachvolleyball." />
      <section className="hero">
        <div className="hero-inner">
          <div>
            <img src="/logo.png" alt="Volker & Olga – Logo" className="hero-logo glow"/>
            <h1>Hochzeitsfeier am Strand – Volker & Olga</h1>
            <p className="lead">Beachfeeling im <b>BlueBeach Witten</b> mit Sonne, Sand und Liebe. Fingerfood & Drinks inklusive.</p>
            <div className="chips">
              <span className="chip">{date}</span>
              <span className="chip">BlueBeach · Witten</span>
              <span className="chip">Sommer-Vibes</span>
            </div>
            <div className="mt"><Countdown/></div>
            <div className="cta-row">
              <a href="/anmeldung" className="btn primary">Jetzt anmelden</a>
              <a href="/anfahrt" className="btn">Anfahrt</a>
            </div>
          </div>
          <div className="hero-card-grid">
            <Card title="Sommerfeeling">
              <p>Sand zwischen den Zehen, Palmen & Lichterketten – gemütlich & elegant.</p>
            </Card>
            <<Card title="Beachvolleyball">
              <p>Wer mag, spielt ein paar lockere Runden. Zuschauer willkommen!</p>
            </Card>
            <Card title="Drinks & Fingerfood">
              <p>Unkompliziert genießen – vegetarische Optionen vorhanden.</p>
            </Card>
          </div>
        </div>
      </section>

      <section className="gallery">
        {imgs.map((i,idx)=>(
          <img key={idx} alt={i.alt} src={i.src} onClick={()=>setOpen(i.src)} />
        ))}
        <Lightbox src={open} alt="Galerie" onClose={()=>setOpen(null)} />
      </section>
    </div>
  )
}
