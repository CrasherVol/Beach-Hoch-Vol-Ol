import Card from '../components/Card.jsx'
import SEO from '../components/SEO.jsx'

export default function Anfahrt(){
  return (
    <div className="page">
      <SEO title="Anfahrt – BlueBeach Witten" description="Adresse, Karte und Parkhinweise für das BlueBeach in Witten."/>
      <h2>Anfahrt zum BlueBeach in Witten</h2>
      <div className="grid2">
        <Card title="Adresse">
          <p>BlueBeach Witten<br/>Ruhrtalstraße 275<br/>58454 Witten</p>
          <div className="btn-row">
            <a className="btn primary" target="_blank" href="https://www.google.com/maps/search/?api=1&query=BlueBeach+Witten" rel="noreferrer">In Google Maps öffnen</a>
          </div>
        </Card>
        <Card title="Karte">
          <div className="map-wrap">
            <iframe title="BlueBeach Map" className="map" loading="lazy" referrerPolicy="no-referrer-when-downgrade" src="https://www.google.com/maps?q=BlueBeach%20Witten&output=embed"></iframe>
          </div>
        </Card>
      </div>
      <div className="grid2">
        <Card title="Parken & ÖPNV">
          <ul>
            <li>Parkplätze am Gelände vorhanden.</li>
            <li>Bitte Fahrgemeinschaften bilden.</li>
            <li>ÖPNV: Bus/S‑Bahn bis Witten, dann kurzer Weg/Taxi.</li>
          </ul>
        </Card>
      </div>
    </div>
  )
}
