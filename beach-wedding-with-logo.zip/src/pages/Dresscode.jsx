import Card from '../components/Card.jsx'
import SEO from '../components/SEO.jsx'

export default function Dresscode(){
  return (
    <div className="page">
      <SEO title="Dresscode – Elegant & Beachy" description="Sommerlich-elegante Outfits, bequem im Sand – Beispielideen und Tipps."/>
      <h2>Dresscode: Elegant & Beachy</h2>
      <div className="grid2">
        <Card title="Für Sie (Beispiele)">
          <ul>
            <li>Leichtes Sommerkleid (Leinen/Chiffon)</li>
            <li>Elegante Sandalen / Keilabsätze (flach empfohlen)</li>
            <li>Farben: Pastell, sand, türkis, koralle</li>
            <li>Optional: Sonnenhut, Tuch</li>
          </ul>
        </Card>
        <Card title="Für Ihn (Beispiele)">
          <ul>
            <li>Leinenhemd oder feines Polo, evtl. leichtes Sakko</li>
            <li>Chino/Leinenhose, ggf. kurze Stoffhose</li>
            <li>Saubere Sneakers/Loafer</li>
            <li>Farben: hell, natur, navy</li>
          </ul>
        </Card>
      </div>
      <div className="grid3">
        <Card title="Bitte vermeiden">
          <ul>
            <li>Sehr dunkle Business‑Looks</li>
            <li>Hohe Stilettos (im Sand unpraktisch)</li>
            <li>Zu sportliche Trainingskleidung</li>
          </ul>
        </Card>
        <Card title="Tipps">
          <ul>
            <li>Leichte Jacke/Tuch für den Abend</li>
            <li>Sonnencreme & Sonnenbrille</li>
            <li>Ersatzschuhe für den Sand, wer mag</li>
          </ul>
        </Card>
        <Card title="Mood">
          <p>Denkt an eine elegante Strandbar – leicht, fröhlich, stilvoll.</p>
        </Card>
      </div>
    </div>
  )
}
